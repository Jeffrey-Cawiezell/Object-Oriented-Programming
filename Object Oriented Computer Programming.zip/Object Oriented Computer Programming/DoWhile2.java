Switch(operator){
	case "+":
		result = firstInteger + secondInteger;
		break;
	case "-":
		result = firstInteger - secondInteger;
		break;
	default:
		break;
}