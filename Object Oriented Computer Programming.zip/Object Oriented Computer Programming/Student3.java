public class Student{

	//attributes
	public int height;
	public String firstName;
	public String lastName;
	public int age;
	public String gender;
	public String classification;
	
	//methods
	
}