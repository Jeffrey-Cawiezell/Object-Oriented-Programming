public class Rectangle extends Shape{
	protected int length;
	protected int width;

	public Rectangle(){
		sides = 4;
		length = 0;
		width = 0;
	}

	public Rectangle(int length, int width){
		sides = 4;
		this.length = length;
		this.width = width;
	}

	@Override
	public double computeArea(){
		return length * width;
	}
}