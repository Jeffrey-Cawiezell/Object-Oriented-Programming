import java.util.Scanner;
import java.io.*;

public class PGM extends Image{
	private int[][] image;

	public PGM(){
		int columns = 0;
		int rows = 0;
		magic = "";
		width = 0;
		height = 0;
		depth = 0;
	}
	
	public PGM(String fileName){
		int columns = 0;
		int rows = 0;
		File file = new File(fileName);
		Scanner sc = null; 
		try {
			sc = new Scanner(file);
		} catch (FileNotFoundException e){
			System.out.println("file not found");
			System.exit(0);
		}
		if(sc.hasNextLine()){
			magic = sc.nextLine();
		}
		if(sc.hasNextInt()){
			width = sc.nextInt();
		}
		if(sc.hasNextInt()){
			height = sc.nextInt();
		}
		if(sc.hasNextInt()){
			depth = sc.nextInt();
		}
		image = new int[height][width];
		for(rows = 0; rows < height; rows++){
			for(columns = 0; columns < width; columns++){
				image[rows][columns] = sc.nextInt();
			}
		}
		sc.close();
	}
	public String getMagic(){
		return magic;
	}
	public int getWidth(){
		return width;
	}
	public int getHeight(){
		return height;
	}
	public int getDepth(){
		return depth;
	}

	public int[][] getPixels(){
		return image;
	}

	public void setMagic(String m){
		this.magic = m;
	}
	public void setWidth(int w){
		this.width = w;
	}
	public void setHeight(int h){
		this.height = h;
	}
	public void setDepth(int d){
		this.depth = d;
	}

	public void save(String fileName){
		PrintWriter writer = null;
	try{
		writer = new PrintWriter(fileName);
	} catch(FileNotFoundException e){
		System.out.println("Unable to create output file.");
		return;
	}
    writer.println(getMagic());
    writer.println(getWidth() + " " + getHeight());
    writer.println(getDepth());
    for(int rows = 0; rows < height; rows++){
		for(int columns = 0; columns < width; columns++){
			writer.print(image[rows][columns] + " ");
		}
		writer.println();
	}
		
    writer.close();
	}

	@Override
	public void flip_horizontally(){
		int[][] newImage;
		newImage = new int[height][width];
		for(int rows = 0; rows < height; rows++){
			for(int destColumns = 0, sourceColumns = width-1; destColumns < width; destColumns++, sourceColumns--){
				newImage[rows][destColumns] = image[rows][sourceColumns];
			}
		}
		image = newImage;
	}
	
	@Override
	public void flip_vertically(){
		int[][] newImage;
		newImage = new int[height][width];
		for(int destRows = 0, sourceRows = height-1; destRows < height; destRows++, sourceRows--){
			for(int columns = 0; columns < width; columns++){
				newImage[destRows][columns] = image[sourceRows][columns];
			}
		}
		image = newImage;
	}
	
	@Override
	public void rotate_right_90(){
		int[][] newImage;
		newImage = new int[width][height];
		for(int destColumns = height-1, sourceRows = 0; sourceRows < height; sourceRows++, destColumns--){
			for(int destRows = 0, sourceColumns = 0; sourceColumns < width; sourceColumns++, destRows++){
				newImage[destRows][destColumns] = image[sourceRows][sourceColumns];
			}
		}
		image = newImage;
		int newWidth = width;
		width = height;
		height = newWidth;
	}
}