import java.util.Scanner;

public class New_Keyword{
	public static void main(String [] args){
		Scanner sc = new Scanner(System.in);
		System.out.print("How many integers are in your list? ");
		int size = sc.nextInt();
		int sum = 0;
		int[] a = new int[size];
		for(int i = 0; i < size; i++)
		{

			System.out.print("Please enter an integer: ");
			a[i] = sc.nextInt();
			sum += a[i];
		}
		for(int i = 0; i < size; i++)
		{
			System.out.printf("%5d\n", a[i]);
		}
			System.out.println("-----");
			System.out.printf("%5d\n", sum);
		return;
	}
}