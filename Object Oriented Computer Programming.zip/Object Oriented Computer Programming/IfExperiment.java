public class IfExperiment{
	public static void main (String [] args){
		String = a;
		String = 10;
		if(a<=10){
			System.out.println("Correct.");
		}
		else{
			System.out.println("Incorrect.");
		}
	}
}