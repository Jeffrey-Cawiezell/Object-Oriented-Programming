public class Shape{
	protected int sides;

	public Shape(){
		sides = 0;

	}
	public Shape(int sides){
		this.sides = sides;
	}

	public double computeArea(){
		return 0.0;
	}
}