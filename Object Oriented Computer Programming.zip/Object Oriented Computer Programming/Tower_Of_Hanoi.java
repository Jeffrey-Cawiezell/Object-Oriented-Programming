import java.util.Scanner;

public class Tower_Of_Hanoi{

	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.print("How many disc must be moved from A to C? ");
		int numberDisks = sc.nextInt();
		solve(numberDisks, 'A', 'B', 'C');
	}

	public static void solve(int diskN, char alpha, char beta, char charley){
		if(diskN == 1){
			System.out.println("Move a disc from " + alpha + " to " + charley + ".");
		}
		else{
			solve(diskN - 1, alpha, charley, beta);
			System.out.println("Move a disc from " + alpha + " to " + charley + ".");
			solve(diskN -1, beta, alpha, charley);
		}
	}
}