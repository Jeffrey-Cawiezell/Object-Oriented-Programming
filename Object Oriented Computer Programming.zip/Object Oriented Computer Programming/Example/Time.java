public class Time {
  
}
