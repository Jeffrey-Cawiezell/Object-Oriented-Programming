public interface Printable{
	public void print();
	public void foo();
}