public abstract Animal{
	protected int legs;
	protected String name;
	public Animal(){

	}
	public abstract void speak();

}