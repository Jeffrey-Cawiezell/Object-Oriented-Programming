public class Student{
	private String firstName;
	private String lastName;

	//default constructor
	public Student(){
		firstName = "";
		lastName = "";
	}
	public Student(String first, String last){
		firstName = first;
		lastName = last;
	}
	//Method that returns student's fullname
	public String getFullName(){ //non static method
		return firstName + " " + lastName;
	}
	public String getFirstName(){
		return firstName;
	}
	public String getLastName(){
		return lastName;
	}
	public void changeFirstName(String str){
		firstName = str;
	}
	public void changeLastName(String str){
		lastName = str;
	}
}