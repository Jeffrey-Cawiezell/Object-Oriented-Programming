import java.util.Scanner;
public class Switch2{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.print("Please enter your grade: ");
		int points = sc.nextInt();

		int num = points / 10;
		switch(num){
			case 10:
				System.out.println("A grade of " + points + " is an A.");
				break;
			case 9:
				System.out.println("A grade of " + points +" is an A.");
				break;
			case 8:
				System.out.println("A grade of " + points + " is a B.");
				break;
			case 7:
				System.out.println("A grade of " + points + " is an C.");
				break;
			case 6:
				System.out.println("A grade of " + points + " is an D.");
				break;
			case 5:
				System.out.println("A grade of " + points + " is an F.");
				break;
			case 4:
				System.out.println("A grade of " + points + " is an F.");
				break;
			case 3:
				System.out.println("A grade of " + points + " is an F.");
				break;
			case 2:
				System.out.println("A grade of " + points + " is an F.");
				break;
			case 1:
				System.out.println("A grade of " + points + " is an F.");
				break;
			case 0:
				System.out.println("A grade of "+ points + " is an F.");
				break;
			default:
				System.out.println("A grade of "+ points + " is not valid.");
				break;


		}
	}
}