import java.lang.Math;

public class Determinant{
	public static void main (String [] args){
		double b;
		double c;
		double d;
		b = Double.parseDouble(args[0]);
		c = Double.parseDouble(args[1]);
		d = Double.parseDouble(args[2]);
		double ans = Math.pow(b,2) * Math.pow(c,2) - 4 * Math.pow(c,3) - 4 * Math.pow(b,3) * d - 27 * Math.pow(d,2) + 18 * b * c * d;
        //System.out.println("The discriminant of the polynomial x^3 + " + b + "x^2 + " + c + "x + " + d + " is " + ans);
		System.out.printf("The discriminant of the polynomial x^3 + %.2fx^2 + %.2fx + %.2f is %.2f", b, c, d, ans);
	}
}