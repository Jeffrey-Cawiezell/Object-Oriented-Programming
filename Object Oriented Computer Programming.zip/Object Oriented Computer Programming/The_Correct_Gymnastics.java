import java.util.Scanner;
public class The_Correct_Gymnastics{
	public static void main(String [] args){
		Scanner sc = new Scanner(System.in);
		double [] scores = new double [7];

		double min = 0;
		double max = 0;

		for(int i = 0; i < 7; i++){
			scores[i] = sc.nextDouble();
		}
		min = scores[0];
		max = scores[0];
		for(int i = 0; i < 7; i++){
			if(scores[i] < min){
				min = scores[i];
			}
			if(scores[i]> max){
				max = scores[i];
			}
			total += scores;
		}
		total -= min;
		total -= max;
		double avg = total/ 5.0;

		System.out.printf("%.2f", avg;)
	}
}