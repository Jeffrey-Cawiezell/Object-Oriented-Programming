public class Dog extends Animal implements Printable{
	public Dog(){
		legs = 4;
		name = "Dog";
	}

	public void speak(){
	String speak = "Bark";	
	}



@Override
	public void print(){

	}
	public void foo(){
		
	}
}