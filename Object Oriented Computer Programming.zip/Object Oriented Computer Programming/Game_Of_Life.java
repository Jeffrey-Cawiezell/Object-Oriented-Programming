import java.util.Scanner;
public class Game_Of_Life{

	private	static final char DEAD = '-';
	private static final char LIVE = 'O';

	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		char[][] array;

		System.out.println("The Game of Life");
		System.out.print("How many steps in time? ");
		int time = sc.nextInt();

		System.out.print("What size is the grid? ");
		int size = sc.nextInt();
		array = new char[size][size];
		System.out.println();

		System.out.println("Enter the initial grid layout: ");
		grid(array, sc);
		for(int i = 0; i < time; i++){
			char[][] new_array;
			new_array = new char[size][size];
			for(int y = 0; y < new_array[0].length; y++){
				for(int x = 0; x < new_array[0].length; x++){
					int newValue = neighbors(array, x, y);
					if(array[x][y] == LIVE){
						if(newValue < 2){
							new_array[x][y] = DEAD;
						}
						if(newValue == 2 || newValue == 3){
							new_array[x][y] = LIVE;
						}
						if(newValue > 3){
							new_array[x][y] = DEAD;
						}
					}
					else{
						if(newValue == 3){
							new_array[x][y] = LIVE;
						}
						else{
							new_array[x][y] = DEAD;
						}
					}
				}
			}
			array = new_array;
		}
		System.out.println("After " + time + " step(s):");
		print(array);
	}

	public static int neighbors(char[][] array, int x, int y){
		int count = 0;
		count += getLiveValue(array, x-1, y);
		count += getLiveValue(array, x-1, y+1);
		count += getLiveValue(array, x, y+1);
		count += getLiveValue(array, x+1, y+1);
		count += getLiveValue(array, x+1, y);
		count += getLiveValue(array, x+1, y-1);
		count += getLiveValue(array, x, y-1);
		count += getLiveValue(array, x-1, y-1);
		return count;
	}
	public static int getLiveValue(char[][] array, int x, int y){
		if(x < 0|| y < 0 || x >= array[0].length || y >= array[0].length){
			return 0;
		}
		if(array[x][y] == LIVE){
			return 1;
		}
		return 0;
	}

	public static void grid(char[][] array, Scanner sc){
		String line;
		sc.nextLine();
		for(int i = 0; i < array[0].length; i++){
			line = sc.nextLine();
			for(int j = 0; j < array[0].length; j++){
				if(j < line.length()){
					array[i][j] = line.charAt(j);
				}
				else{
					array[i][j] = DEAD;
				}
			}
		}
	}

	public static void print(char[][] array){
		for(int i = 0; i < array[0].length; i++){
			for(int j = 0; j < array[0].length; j++){
				System.out.print(array[i][j]);
			}
			System.out.println();
		}
	}
}