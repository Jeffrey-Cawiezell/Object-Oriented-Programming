public class Triangle extends Shape{
	protected int height;
	protected into base;

	public Triangle(){
		sides = 3;
		height = 0;
		base = 0;
	}

	public Triangle(int height, int base){
		sides = 3;
		this.height = height;
		this.base = base;
	}

	@Override
	public double computeArea(){
		return (height * base) / 2.0;
	}
}