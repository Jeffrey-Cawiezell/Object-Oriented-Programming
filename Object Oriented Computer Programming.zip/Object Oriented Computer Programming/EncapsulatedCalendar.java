public class EncapsulatedCalendar{
	private int day;
	private int month;
	private int year;
	public EncapsulatedCalendar(){
		day = 1;
		month = 1;
		year = 2017;
	}
	public void setDay(){
		for(int i = 0; i < 30; i++){
			day = i;
			if(day > 30){
				day = 1;
			}
		}
	}
	public void setMonth(){
		if(day > 30){
			month++;
			day = 1;
		}
		if(month > 12){
			month = 1;
		}
	}
	public void setYear(){
		if(month > 12){
			year++;
			day = 1;
			month = 1;
		}
	}
	public int getDay(){
		return day;
	}
	public int getMonth(){
		return month;
	}
	public int getYear(){
		return year;
	}
}