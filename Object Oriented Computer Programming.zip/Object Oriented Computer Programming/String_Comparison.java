import java.util.Scanner;
public class String_Comparison{
	public static void main(String [] args){
		String choice;
		Scanner sc = new Scanner (System.in);

		System.out.print("Please enter the first word: ");
		String firstWord = sc.next();
		System.out.print("Please enter the second word: ");
		String secondWord = sc.next();
		if(firstWord.equals(secondWord)){
			System.out.println(firstWord + " is the same as " + secondWord + ".");
		}
		else if(firstWord.compareTo(secondWord) < 0){
        	System.out.println(firstWord + " is less than " + secondWord + ".");
		}
		else{
			System.out.println(firstWord + " is greater than " + secondWord + ".");
		}
	}
}