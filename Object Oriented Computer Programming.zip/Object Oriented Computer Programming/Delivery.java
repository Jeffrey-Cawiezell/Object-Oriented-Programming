import java.util.Scanner;
public class Delivery{
	public static void main(String [] args){
		Scanner sc = new Scanner(System.in);
		
		int [] zips = {12789, 54012, 54481, 54982, 60007, 60103, 60187, 60188, 71244, 90210};
		double [] prices = {2.40, 3.00, 3.50, 4.00, 4.50, 5.00, 5.25, 5.75, 6.10, 10.00};
		
		System.out.println("Delivery Charge");
		System.out.print("Enter a ZIP code for delivery: ");
		
		int elements = sc.nextInt();
		boolean match = false;
		for(int i = 0; i < zips.length; i++){
			if(elements == zips[i]){
				match = true;
				System.out.println("Delivery charge is: " + prices[i]);
			}
		}
			if(!match){
				System.out.println("Sorry: no delivery to " + elements);
			}
	}
}