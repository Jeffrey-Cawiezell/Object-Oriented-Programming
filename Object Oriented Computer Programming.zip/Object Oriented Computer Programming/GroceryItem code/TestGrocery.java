//Made by Jace Cawiezell and Derek Ogle
public class TestGrocery{
	public static void main(String[] args){
		String[] list = {apples, bananas, oranges, grapes, three musketeers, skittles, recess, mike&ikes, chips, soda};
		GroceryItem list = new GroceryItem();
		System.out.println(List.dataEntry());
	}
}