import java.util.Scanner;
public class GroceryItem{
	private int stock = 0;
	private int number = 0;
	private int price = 0;
	private int quantity = 0;
	private int total_Value = price * quantity;
	public void dataEntry(){
			stockNumber();
			getPrice();
			quantity_In_Stock();
	}
		Scanner sc = new Scanner(System.in);
		private int stockNumber(){
			System.out.println("Type a number between 1000 to 9999.");
			stock = sc.nextInt();
			if((stock >= 1000)&&(stock <= 9999)){
				stock = stock;
			}
			else{
				System.out.println("That value does not work.");
				return this.stock;
			}
			return stock;
		}
		private int getPrice(){
			price = sc.nextInt();
			return price;
		}
		private int quantity_In_Stock(){
			quantity = sc.nextInt();
			return quantity;
		}
}
