import java.util.Scanner;
public class Plural_Form{
	public static String PluralForm(String word){
		if(word.charAt(word.length()-1) == 's' || word.charAt(word.length()-1) == 'x' || word.charAt(word.length()-1) == 'z'){
			System.out.print(word + "es");
		}
		else if(word.charAt(word.length()-1)== 'h' && (word.charAt(word.length()-2) == 'c' || word.charAt(word.length()-2) == 's')){
			System.out.print(word + "es");
		}
		else if(word.charAt(word.length()-1) == 'o' && (word.charAt(word.length()-2) != 'a' && word.charAt(word.length()-2) != 'e' && word.charAt(word.length()-2) != 'i' && word.charAt(word.length()-2) != 'u' && word.charAt(word.length()-2) != 'o')){
			System.out.print(word + "es");
		}
		else if(word.charAt(word.length()-1) == 'y' && (word.charAt(word.length()-2) != 'a' && word.charAt(word.length()-2) != 'e' && word.charAt(word.length()-2) != 'i' && word.charAt(word.length()-2) != 'u' && word.charAt(word.length()-2) != 'o')){
			word = word.substring(0, word.length()-1);
			System.out.print(word + "ies");
		}
		else{
			System.out.print(word + "s");
		}
		return "";
	}

	public static void main(String[] args){
		System.out.println("This program converts an English word to its plural form.");
		System.out.println();
		Scanner sc = new Scanner(System.in);
		System.out.print("English word: ");
		String w = sc.nextLine();

		String p = "";
		if(w.charAt(w.length()-1) == '.' || w.charAt(w.length()-1) == ',' || w.charAt(w.length()-1) == '!' || w.charAt(w.length()-1) == '?' || w.charAt(w.length()-1) == ';'){
			p = w.substring(w.length()-1, w.length());
			w = w.substring(0, w.length()-1);
		}
		System.out.print("Plural form: ");
		PluralForm(w);
		System.out.println(p);
	}
}