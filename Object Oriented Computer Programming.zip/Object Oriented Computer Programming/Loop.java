public class Loop{
	public static void main (String [] args){
		int counter = 0;
		while(counter<20){
			if((counter%2)==1){
				System.out.println(counter);

			}
			counter = counter + 1;
			
		}
	}
}