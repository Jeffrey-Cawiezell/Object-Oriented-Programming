import java.util.Scanner;

public class DoWhile{	
	public static void main(String [] args){
		String choice;
			System.out.println("Basic Calculator Program");
		
			//getting first input
			Scanner sc = new Scanner (System.in);
		do{
			System.out.print("Enter the first integer: ");
			int firstInteger = sc.nextInt();
		
			//getting second input
			System.out.print("Enter the second integer: ");
			int secondInteger = sc.nextInt();
		
			//getting third input
			System.out.print("Enter the operator: ");
			String operator = sc.next(); //"+", "-", "*", "/"

			int result = 0;
			if (operator.equals("+")){
				result = firstInteger + secondInteger;
				System.out.println("The result is: " + result);
			}
			else if (operator.equals("-")){
				result = firstInteger - secondInteger;
				System.out.println("The result is: " + result);
			}
			else if (operator.equals("*")){
				result = firstInteger * secondInteger;
				System.out.println("The result is: " + result);
			}
			else if (operator.equals("/")){
				if (secondInteger == 0){
					System.out.println("Error: cannot divide by zero.");
				}
				else{
				result = firstInteger / secondInteger;
				System.out.println("The result is: " + result);
			}
			}
			else{
				System.out.println("Invalid operation.");
			}
			

			System.out.print("Another operation (y/n)? ");

			choice = sc.next();
		}
		while(choice.equals("y"));

	}
}