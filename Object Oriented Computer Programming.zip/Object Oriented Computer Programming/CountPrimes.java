import java.lang.Math;
import java.util.Scanner;
public class CountPrimes{
	public static void main(String [] args){
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		boolean [] array = new boolean[n];
		for(int i = 0; i < n; i++){
			array[i] = true;
		}

		for(int i = 2; i <= Math.sqrt(n); i++){
			for(int j = 2; j <= n; j++){
				if(i*j <= n){
					array[(i*j)-1] = false;
				}
			}
		}

		int count = 0;
		for(int i = 1; i < n; i++){
			if(array[i] == true){
				count++;
			}
		}
		System.out.println(count);
	}
}