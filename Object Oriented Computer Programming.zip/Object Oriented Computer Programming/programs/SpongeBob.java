public class SpongeBob{
	public static void main (String [ ] args){

	System.out.println("      .--..--..--..--..--..--.");
	System.out.println("    .' \\  (`._   (_)     _   \\");
	System.out.println("  .'    |  '._)         (_)  |");
	System.out.println("  \\ _.')\\      .----..---.   /");
	System.out.println("  |(_.'  |    /    .-\\-.  \\  |");
	System.out.println("  \\     0|    |   ( O| O) | o|");
	System.out.println("   |  _  |  .--.____.'._.-.  |");
	System.out.println("   \\ (_) | o         -` .-`  |");
	System.out.println("    |    \\   |`-._ _ _ _ _\\ /");
	System.out.println("    \\    |   |  `. |_||_|   |");
	System.out.println("    | o  |    \\_      \\     |     -.   .-.");
	System.out.println("    |.-.  \\     `--..-'   O |     `.`-' .'");
	System.out.println("  _.'  .' |     `-.-'      /-.__   ' .-'");
	System.out.println(".' `-.` '.|='=.='=.='=.='=|._/_ `-'.'");
	System.out.println("`-._  `.  |________/\\_____|    `-.'");
	System.out.println("   .'   ).| '=' '='\\/ '=' |");
	System.out.println("   `._.`  '---------------'");
	System.out.println("           //___\\   //___\\");
	System.out.println("             ||       ||");	
	System.out.println("             ||_.-.   ||_.-.");	
	System.out.println("            (_.--__) (_.--__)");
	
	return;

	}
}