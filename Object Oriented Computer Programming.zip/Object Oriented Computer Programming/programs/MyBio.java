import java.util.Scanner;
public class MyBio {
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.print("first name: " + name);
	String FirstName = sc.nextLine();
	String Address = sc.nextLine();
	System.out.println("Last name: " + name);
	String LastName = sc.nextLine();
	System.out.println("DOB: " + DOB);
		String DOB = sc.nextLine();
	System.out.println("address: " + Address);
	String Address = sc.nextLine();
	
	return;
	}	
}