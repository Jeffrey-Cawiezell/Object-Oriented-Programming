//Import Scanner library
import java.util.Scanner;
public class BioScanner{
	public static void main(String[] args){
		Scanner myScanner = new Scanner(System.in);
		System.out.print("Enter name: ");
		String name = myScanner.nextLine(); //read the whole line
		System.out.println("Hello " + name);

	}
}