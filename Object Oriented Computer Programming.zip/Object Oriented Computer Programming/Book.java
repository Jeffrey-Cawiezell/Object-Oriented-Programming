import java.io.*;
import java.util.*;
public class Book{
	private String title;
	private String contents;
	private double printingCost;
	private int pages;

	public Book(){
		title = "";
		contents = "";
		pages = 0;
		printingCost = 0;
	}

	public Book(String c, String t){
		this.contents = c;
		this.title = t;
	}

	public void getTitle(){
		return title;
	}

	public void getContents(){
		return contents;
	}

	public void getPages(){
		setPages();
		return pages;
	}

	public void getPrintingCost(){
		setPrintingCost();
		return printingCost();
	}
	public double setPrintingCost(){
		for(int i = 0; i < contents.length; i++){
			if(contents.charAt(i) == ""||contents.charAt(i) == " " || contents.charAt(i)=="\n"){
			}
			else{
				printingCost = printingCost + 0.50;
			}
		}
		return printingCost;
	}

	public int setPages(){
		for(int i = 0; i < contents.length(); i++){
			if(contents.length() >= 5){
				pages++;
			}
			else{
				return pages;
			}
		}
			return pages;
	}

	public void encrypt(int key){

	}

	public void print(){
		getTitle();
		getContents();
		getPages();
		getPrintingCost();
		System.out.println("Title: " + title);
		System.out.println("Body: " + contents);
		System.out.print("Cost: $");
		System.out.printf("%3d", printingCost);
		System.out.println();
		System.out.println("Pages: " + pages);
	}
}