public class Fraction{
	private int whole;
	private int numerator;
	private int denominator;
	private int divisor;
	public Fraction(){
		whole = 0;
		numerator = 0;
		denominator = 1;
	}

	public Fraction(int numerator, int denominator){
		whole = 0;
	}

	public Fraction(int whole, int numerator, int denominator){

	}

	int gcd(int a, int b){
		if(b == 0){
			return a;
		}
		return gcd(b, a%b);
	}

	public void reduce(){
		divisor = gcd(numerator, denominator);
		numerator = numerator / divisor;
		denominator = denominator / divisor;
	}

	public Fraction add(Fraction A){
		Fraction B = new Fraction();
		B.numerator = ((((this.whole * this.denominator) + this.numerator) * A.denominator) + ((A.whole * A.denominator) + A.numerator) * this.denominator);
		B.denominator = this.denominator * A.denominator;
		numerator = B.numerator;
		denominator = B.denominator;
		reduce();
		return B;
	}

	public Fraction substract(Fraction A){
		Fraction B = new Fraction();
		B.numerator = ((((this.whole * this.denominator) + this.numerator) * A.denominator) - ((A.whole * A.denominator) + A.numerator) * this.denominator);
		B.denominator = this.denominator * A.denominator;
		numerator = B.numerator;
		denominator = B.denominator;
		reduce();
		return B;
	}

	public Fraction multiply(Fraction A){
		Fraction B = new Fraction();
		B.numerator = ((((this.whole * this.denominator) + this.numerator) * A.denominator) * ((A.whole * A.denominator) + A.numerator) * this.denominator);
		numerator = B.numerator;
		denominator = B.denominator;
		reduce();
		return B;
	}

	public Fraction divide(Fraction A){
		Fraction B = new Fraction();
		B.numerator = ((((this.whole * this.denominator) + this.numerator) * A.denominator) / ((A.whole * A.denominator) + A.numerator) * this.denominator);
		numerator = B.numerator;
		denominator = B.denominator;
		reduce();
		return B;
	}

	public String toString(){
		if(whole == 0){
			return numerator + "/" + denominator;
		}
		else if(numerator == 0){
			return whole + "/n";
		}
		else{
			return whole + " " + numerator + "/" + denominator;
		}
	}
}