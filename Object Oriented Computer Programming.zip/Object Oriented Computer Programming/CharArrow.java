public class CharArrow{
	public static void main (String [] args){
		char arrowBody = '-'
		char arrowHead = '>'

		System.out.println(arrowHead);
		System.out.println("" + arrowBody + arrowHead);

		arrowBody = '0';
		System.out.println("" + arrowBody + arrowHead);
	}
}