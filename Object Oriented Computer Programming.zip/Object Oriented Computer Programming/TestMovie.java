public class TestMovie{
	public static void main(String[] args){
		Movie myFavoriteMovie = new Movie();
		myFavoriteMovie.setTitle("Cool movie");
		myFavoriteMovie.setYear(2000);
		myFavoriteMovie.setDirector("Brad Pitt");

		myFavoriteMovie.display();
	}
}