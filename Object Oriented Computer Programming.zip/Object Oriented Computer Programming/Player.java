public class Player extends GenericPlayer implements Reportable{

	private String name;
	private int losses;
	private int wins;
	private int ties;

	public Player(){
		name = "";
		losses = 0;
		wins = 0;
		ties = 0;
	}
	public Player(String name){
		this();
		this.name = name;
	}
	public void setName(String name){
		this.name = name;
	}
	public void playOpponent(Player player2, String p1choice, String p2choice){
		if(p1choice.equals(p2choice)){
			ties++;
			player2.ties++;
		}
		else{
			if(p1choice.equals("rock")&&p2choice.equals("scissors")){
				wins++;
				player2.losses++;
			}
			else if(p1choice.equals("scissors")&&p2choice.equals("paper")){
				wins++;
				player2.losses++;
			}
			else if(p1choice.equals("paper")&&p2choice.equals("rock")){
				wins++;
				player2.losses++;
			}
			else{
				player2.wins++;
				losses++;
			}
		}
	}
	public void printLossPercentage(){

	}
	public double getLossPercentage(){
		return (double)losses/(wins + losses);
	}
	public int getNumberOfTies(){
		return ties;
	}
	public int getNumberOfWins(){
		return wins;
	}
	public int getNumberOfLosses(){
		return losses;
	}
	public String getName(){
		return name;
	}
	public void printWinPercentage(){
		System.out.print(name + "'s win rate: ");
		if(losses+wins+ties == 0){
			System.out.println("0.00");
		}
		else{
			System.out.printf("%.2f\n",getWinPercentage());
		}
	}
	public double getWinPercentage(){
		return (double)wins/(wins + losses);
	}
	public void printTies(){
		System.out.println(name + " has " + ties + " tie(s)");
	}
	@Override
	public void report(){
		System.out.println("Name: " + getName());
		System.out.println("Wins: " + getNumberOfWins());
		System.out.println("Losses: " + getNumberOfLosses());
		System.out.println("Ties: " + getNumberOfTies());
	}
}