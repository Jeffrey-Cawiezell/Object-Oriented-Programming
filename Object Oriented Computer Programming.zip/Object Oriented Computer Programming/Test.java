    import java.util.Random;

    public class Test
    {
        public static void main(String[] args)
        {
              String p1name = "Player 1";
  String p2name = "Player 2";

  Player p1 = new Player(p1name);
  Player p2 = new Player(p2name);

  p1.playOpponent(p2, "rock", "scissors");
  p1.playOpponent(p2, "paper", "paper");
  p1.playOpponent(p2, "paper", "rock");
  p1.playOpponent(p2, "scissors", "rock");

  assert(p1.getWinPercentage() == 0.50): "p1.getWinPercentage() == 0.50";
  assert(p1.getNumberOfTies() == 1): "p1.getNumberOfTies() == 1";
        }
    }