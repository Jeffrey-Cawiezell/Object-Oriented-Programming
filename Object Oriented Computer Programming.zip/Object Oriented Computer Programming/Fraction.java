public class Fraction{
	private int whole;
	private int numerator;
	private int denominator;
	private int divisor;
	public Fraction(){
		whole = 0;
		numerator = 0;
		denominator = 1;
	}

	public Fraction(int numerator, int denominator){
		whole = 0;
		this.numerator = numerator;
		this.denominator = denominator;
		reduce();
	}

	public Fraction(int w, int n, int d){
		if(w < 0){
			numerator = (w * d) - n;	
		}
		else if (w == 0){
			numerator = n;
		}
		else{
			numerator = (w * d) + n;

		}
		denominator = d;
		reduce();
	}

	public int gcd(int a, int b){
		if(b == 0){
			return a;
		}
		return gcd(b, a%b);
	}

	public void reduce(){
		whole = numerator / denominator;
		numerator = numerator - (whole * denominator);
		divisor = gcd(numerator, denominator);
		numerator = numerator / Math.abs(divisor);
		denominator = denominator / Math.abs(divisor);
	}

	public Fraction add(Fraction A){
		Fraction B = new Fraction();
		B.numerator = (((this.whole * this.denominator) + this.numerator) * A.denominator) + (((A.whole * A.denominator) + A.numerator) * this.denominator);
		B.denominator = this.denominator * A.denominator;
		B.reduce();
		return B;
	}

	public Fraction substract(Fraction A){
		Fraction B = new Fraction();
		B.numerator = (((this.whole * this.denominator) + this.numerator) * A.denominator) - (((A.whole * A.denominator) + A.numerator) * this.denominator);
		B.denominator = this.denominator * A.denominator;
		B.reduce();
		return B;
	}

	public Fraction multiply(Fraction A){

		Fraction B = new Fraction();
		B.numerator = ((this.whole*this.denominator)+this.numerator) * ((A.whole*A.denominator)+A.numerator);
		B.denominator = A.denominator * this.denominator;
		B.reduce();
		return B;
	}

	public Fraction divide(Fraction A){
		Fraction B = new Fraction();
		B.numerator = ((this.whole*this.denominator)+this.numerator) * A.denominator;
		B.denominator = ((A.whole*A.denominator)+A.numerator) * this.denominator;
		B.reduce();
		return B;
	}

	public String toString(){
		if((whole == 0) && (numerator == 0)){
			return 0 + "";
		}
		else if (whole == 0)
		{
			return numerator + "/" + Math.abs(denominator);
		}
		else if(numerator == 0){
			return whole + "";
		}
		else{
			return whole + " " + Math.abs(numerator) + "/" + Math.abs(denominator);
		}
	}
}