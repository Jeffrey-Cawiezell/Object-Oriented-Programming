import java.util.Scanner;
public class Switch{
	public static void main(String [] args){
		Scanner sc = new Scanner(System.in);
		String username = sc.nextLine();
		switch (username){
			case "Robert":
			case "James":
			case "Matthew":
				System.out.println("This is a valid username.");
				break;
			default:
				System.out.println("Invalid username.	The authorities have been notified.");
				break;
		}
	}
}