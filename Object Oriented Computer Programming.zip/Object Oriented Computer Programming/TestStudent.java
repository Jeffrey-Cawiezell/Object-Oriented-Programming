public class TestStudent{
	public static void main(String[] args){
		Student Tom = new Student("Tom", "Tommy");
		System.out.println("Full Name: " + Tom.getFullName());
	}
}