public class Student{
	public String firstName;
	public String lastName;

	//Method that returns student's fullname
	public String getFullName(){ //non static method
		return firstName + " " + lastName;
	}
}