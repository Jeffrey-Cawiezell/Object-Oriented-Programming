public class Main{
	public static void main(String[] args){
		ArrayList<Animal> list = new ArrayList<>()
		Dog medor = new dog();
		list.add(medor);

		for(Animal a: list){
			a.speak();
		}
	}
}