//Made by Jace Cawiezell
public class Time{
	//Attributes
	private int hour;
	private int minutes;
	private int seconds;
	//methods
	public void display(){
		System.out.println(hour + ":" + minutes);
	}

	public Time(){
		hour = 0;
		minutes = 0;
	}

	public Time(int newHour, int newMinutes){
		if(newHour > 23){
			newHour = 23;
		}
		if(newMinutes > 59){
			newMinutes = 59;
		}
		minutes = newMinutes;
		hour = newHour;
	}
	
	public void addMinute(int newMinute){
		if(newMinute == 60){
			newMinute = 00;
			hour = hour + 1;	
		}
		if(newMinute > 60){
			newMinute = newMinute - 60;
			hour = hour + 1;
		}
		minutes = minutes + newMinute;
		if(minutes > 59){
			hour = hour + 1;
			minutes = minutes - 60;
		}
		if(hour > 23){
			hour = hour - 24;
		}
	}
	//testing the program and not part of the actually final product.
	public static void main(String[] args){
		Time A = new Time(3, 30);
		A.addMinute(600000);
		A.display();
	}
}