import java.util.HashMap;
public class StudentGrade{
	public static void main(String[] args){
		HashMap<String, Integer> grades = new HashMap<>();
		grades.put("Ben", 100);
		grades.put("Victoria", 100);


		System.out.println("Ben's grade: " + grades.get("Ben"));
	}
}

/*
"Ben" ==> 100;
"Victoria" ==> 100;
*/