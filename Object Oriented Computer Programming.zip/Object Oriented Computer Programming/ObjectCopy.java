public class ObjectCopy{
	
	public static void main(String[] args){
		Student A = new Student();
		A.setName("John Q");
		Student B = new Student();
		B.setName("Tom Tommy");

		//A = B;
		if(A.compare(B)){
			System.out.println("A is equal to B");
		}
		else{
			System.out.println("A is not equal to B");
		}
		A.setName("Chris S.");
		A.print();
		B.print();
	}

}


	//example class
	class Student{
		private String name;
		
		public void setName(String name){
			this.name = name;
		}

		public void print(){
			System.out.println("Name: " + name);
		}
		public boolean compare(Student AnotherStudent){
			if(this.name.equals(AnotherStudent.name)){
				return true;
			}
			else{
				return false;
			}
			//return this.name.equals(AnotherStudent.name) ? true: false;
		}
	}