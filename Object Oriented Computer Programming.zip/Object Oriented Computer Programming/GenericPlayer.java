public abstract class GenericPlayer{
	//----------------
	//Game Attributes
	//----------------
	protected String name;
	protected int numberOfWins;
	protected int numberOfLosses;
	protected int numberOfTies;
	protected int numberOfGamesPlayed;
	//Accessors:
	public String getName(){
		return name;
	}
	public int getNumberOfWins(){
		return numberOfWins;
	}
	public int getNumberOfLosses(){
		return numberOfLosses;
	}
	public int getNumberOfTies(){
		return numberOfTies;
	}
	public int getNumberOfGamesPlayed(){
		return numberOfGamesPlayed;
	}
	//modifiers:
	public void setName(String m){
		this.name = m;
	}
	public void setNumberOfWins(){
		this.numberOfWins = 0;
	}
	public void setNumberOfLosses(){
		this.numberOfLosses = 0;
	}
	public void setNumberOfTies(){
		this.numberOfTies = 0;
	}
	public void setNumberOfGamesPlayed(){
		this.numberOfGamesPlayed = 0;
	}
	//-------------------
	// abstract functions
	//-------------------
	public abstract double getWinPercentage();
	public abstract void printWinPercentage();
	public abstract double getLossPercentage();
	public abstract void printLossPercentage();
}