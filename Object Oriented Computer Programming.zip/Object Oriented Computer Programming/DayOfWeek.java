public class DayOfWeek{
	public static void main(String [] args){
		int month = Integer.parseInt(args[0]);
		int day = Integer.parseInt(args[1]);
		int year = Integer.parseInt(args[2]);
		int y, x, m, d;
		    y = year - (14 - month) / 12;
    		x = y + y/4 - y/100 + y/400;
   			m = month + 12 * ((14 - month) / 12) - 2;
    		d = (day + x + (31 * m)/ 12) % 7;
		System.out.print(month + " " + day + " " + year + " falls on ");
		switch(d){
			case 0:
				System.out.print("0");
				break;
			case 1:
				System.out.print("1");
				break;
			case 2:
				System.out.print("2");
				break;
			case 3:
				System.out.print("3");
				break;
			case 4:
				System.out.print("4");
				break;
			case 5:
				System.out.print("5");
				break;
			case 6:
				System.out.print("6");
				break;
		}
	}
}