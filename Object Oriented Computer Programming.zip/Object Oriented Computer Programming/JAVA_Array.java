import java.util.Scanner;
public class JAVA_Array{
	public static void main(String [] args){
		Scanner sc = new Scanner(System.in);
		int [] a = {5,3,12,3,6,14,2,9,8,4};
		System.out.print("Please enter an index: ");
		int index = sc.nextInt();

		System.out.println("The element at index " + index + " is " + a[index] + ".");
		return;
	}
}