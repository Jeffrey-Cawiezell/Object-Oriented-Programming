public class Prime_Sieve{
	public static void main(String [] args){

	}
}