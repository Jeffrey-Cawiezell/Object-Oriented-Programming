public class Loop2{
	public static void main(String [] args){
		for(int counter = 0; counter < 20; counter++){
			if ((counter%2)==1){
				System.out.println(counter);
			}
		}
	return;
	}
}