public class Cat extends Animal{
	public Cat(){
	legs = 4;
	name = "Cat";
	}

	public abstract void speak();
}