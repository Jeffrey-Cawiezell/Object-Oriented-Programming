import java.util.Scanner;
public class GymnasticScores{
	public static void main(String [] args){
		Scanner sc = new Scanner(System.in);
		double average = 0;
		double minVal = Double.MAX_VALUE;
		double maxVal = Double.MIN_VALUE;
		double [] array = new double[7];
		double [] averageArray = new double[5];
		int j = 0;

		for(int i = 0; i < 7; i++){
			array[i] = sc.nextDouble();
			if(minVal > array[i]){
				minVal = array[i];
			}
			else if(maxVal < array[i]){
				maxVal = array[i];
			}
			else{
				averageArray[j] = array[i];
				j++;
			}
		}
		
		for(j = 0; j < averageArray.length; j++){
			average += averageArray[j];
		}
		
		average = average/averageArray.length;
		System.out.print("Average score: ");
		System.out.println(average);
	}
}