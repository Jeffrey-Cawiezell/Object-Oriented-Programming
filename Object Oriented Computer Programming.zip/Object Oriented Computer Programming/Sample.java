public class Sample{
    public static void main(String[] args)
    {
        Player p1 = new Player("John Doe");
        Player p2 = new Player("Jane Doe");

        p1.playOpponent(p2, "rock", "paper");

        System.out.println(p2.getWinPercentage());
        System.out.println(p2.getNumberOfTies());

        System.out.printf("\n%s reports: \n", p1.getName());
        p1.report();
    }
}