import java.util.Scanner;
public class PluralForm{
	public String PluralForm(String word){
		if(word.charAt(word.length()-1) == 's' || word.charAt(word.length()-1) == 'x' || word.charAt(word.length()-1) == 'z'){
			System.out.println(word + "es");
		}
		else if(word.charAt(word.length()-1)== 'h' && (word.charAt(word.length()-2) == 'c' || word.charAt(word.length()-2) == 's')){
			System.out.println(word + "es");
		}
		else if(word.charAt(word.length()-1) == 'o' && (word.charAt(word.length()-2) != 'a' || word.charAt(word.length()-2) != 'e' || word.charAt(word.length()-2) != 'i' || word.charAt(word.length()-2) != 'u' || word.charAt(word.length()-2) != 'o')){
			System.out.println(word + "es");
		}
		else if(word.charAt(word.length()-1) == 'y' && (word.charAt(word.length()-2) != 'a' || word.charAt(word.length()-2) != 'e' || word.charAt(word.length()-2) != 'i' || word.charAt(word.length()-2) != 'u' || word.charAt(word.length()-2) != 'o')){
			word = word.substring(0, word.length()-2);
			System.out.println(word + "ies");
		}
		else{
			System.out.println(word + "s");
		}
		return "";
	}

	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		String w = sc.nextLine();
		PluralForm(w);
	}
}